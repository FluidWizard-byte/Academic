
/**
 *
 * @author B.B
 */
public class BinarySearch {
   
    
     static int search(int arr[], int left, int right, int key){
        //int arr[] is the array of sorted integers
        //low is the starting point= 0
        //high is the end point= length of arr-1
        //key is the value we are lookng for
        // binary search works by dividing the array
        
        if (right >= left) { 
            int mid = left + (right - left) / 2; 
            
            //if key is same as the middle value
            if (arr[mid] == key) 
                return mid; 
            
            //if key is smaller than the middle value look left
            if (arr[mid] > key) 
                return search(arr, left, mid - 1, key); 
            
            //if key is biggerer than the middle value look towards right  
            return search(arr, mid + 1, right, key); 
        }
        // if value we search for is not found, -1 is returned
        return -1;
        }
}


