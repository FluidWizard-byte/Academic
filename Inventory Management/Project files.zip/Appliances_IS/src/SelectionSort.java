
/**
 *
 * @author B.B
 */
public class SelectionSort {
//sorted array a is returned
//minposFinder and swap help arrange the elements in the array
    public static String[][] sort(String[][] a) {
        for (int i = 0; i < a.length - 1; i++) {
            int minPos = minPosFinder(a, i);
            swap(a, minPos, i);
        }
        return a;
    }

    public static int minPosFinder(String[][] a, int from) {
        //price is compared a[i][4] gives price in eah array
        int minPos = from;
        for (int i = from + 1; i < a.length; i++) {
            if (Integer.parseInt(a[i][4]) < Integer.parseInt(a[minPos][4])) {
                minPos = i;
            }
        }
        return minPos;
    }

    public static void swap(String[][] a, int minPos, int from) {
        //elements are swapped
        String[] temp = a[minPos];
        a[minPos] = a[from];
        a[from] = temp;

    }

}
